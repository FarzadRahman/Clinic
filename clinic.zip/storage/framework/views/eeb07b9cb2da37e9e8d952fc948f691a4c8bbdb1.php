<?php $__env->startSection('fullScreen'); ?>

<div class="container-fluid mt-5">
    <h3 align="center"><b>Running Serial</b></h3>

    <div class="row" id="runningSerial">


    </div>

    <div class="row ">


























































































    </div>



</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            setInterval(function(){ getSerial(); }, 3000);
        });

        function getSerial() {

            $.ajax({
                type: 'POST',
                url: "<?php echo route('appointment.runSerialGetData'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>"},
                success: function (data) {
                    $("#runningSerial").html(data);

                }
            });

        }

    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>