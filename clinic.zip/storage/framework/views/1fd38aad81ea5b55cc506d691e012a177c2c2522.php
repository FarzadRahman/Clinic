
<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 align="center"><b>Serial : <span style="color: green"><?php echo e($appointment->serialNumber); ?></span></b></h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="form-group col-md-6">
                    <label>Patient Name : <?php echo e($appointment->name); ?></label>
                </div>
                <div class="form-group col-md-6">
                    <label>Mobile : <?php echo e($appointment->mobile_number); ?></label>
                </div>

                <div class="form-group col-md-6">
                    <label>Gender : <?php echo e($appointment->sex); ?></label>
                </div>

                <div class="form-group col-md-6">
                    <label>Doctor Name : <?php echo e($appointment->doctorName); ?></label>
                </div>
            </div>

        </div>
    </div>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>