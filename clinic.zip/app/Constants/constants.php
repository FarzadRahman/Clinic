<?php
define('Gender',array(
    "male",
    "female",
    "other"
));